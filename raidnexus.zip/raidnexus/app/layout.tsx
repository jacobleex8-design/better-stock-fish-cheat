import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RaidNexus — Connect. Raid. Trade.",
  description: "The #1 community platform for coordinating raids, finding friends, and trading in Pokémon GO.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ position: 'relative', zIndex: 1 }}>{children}</body>
    </html>
  );
}
