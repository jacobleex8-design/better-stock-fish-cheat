'use client';
import { useState, useEffect, useRef } from 'react';
import { SAMPLE_RAIDS, SAMPLE_FRIENDS, SAMPLE_TRADES, POKEMON_LIST, REGIONS, TYPES, SLOT_OPTIONS, Raid, FriendListing, Trade, RaidTier, RaidMode, UserProfile } from '@/lib/data';

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function timeLeft(d: Date): { text: string; urgent: boolean } {
  const diff = new Date(d).getTime() - Date.now();
  if (diff <= 0) return { text: 'Expired', urgent: true };
  const m = Math.floor(diff / 60000);
  const urgent = m < 15;
  if (m < 60) return { text: `${m}m left`, urgent };
  return { text: `${Math.floor(m / 60)}h ${m % 60}m`, urgent };
}
function timeAgo(d: Date): string {
  const diff = Date.now() - new Date(d).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  return `${Math.floor(m / 60)}h ago`;
}
function copy(text: string, cb: () => void) {
  navigator.clipboard.writeText(text.replace(/\s/g, '')).then(cb);
}
function avatarColor(name: string): string {
  const colors = ['#00d4ff','#a855f7','#f0b429','#ff4560','#00e676','#ff7a45'];
  return colors[name.charCodeAt(0) % colors.length];
}
function Avatar({ name, size = 36 }: { name: string; size?: number }) {
  const c = avatarColor(name);
  return (
    <div style={{ width: size, height: size, borderRadius: size * 0.28, background: `${c}20`, border: `1.5px solid ${c}50`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Rajdhani, sans-serif', fontWeight: 700, fontSize: size * 0.44, color: c, flexShrink: 0 }}>
      {name[0]?.toUpperCase()}
    </div>
  );
}

// ─── BADGE COMPONENTS ─────────────────────────────────────────────────────────
function TierBadge({ tier }: { tier: RaidTier }) {
  const map: Record<string, [string, string]> = { '1': ['tier-1', 'T1'], '3': ['tier-3', 'T3'], '5': ['tier-5', 'T5'], mega: ['tier-mega', 'MEGA'], elite: ['tier-elite', 'ELITE'] };
  const [cls, label] = map[tier] ?? ['tier-1', tier];
  return <span className={`badge ${cls}`}>{label}</span>;
}
function TypeBadge({ type }: { type: string }) {
  return <span className={`badge t-${type}`}>{type}</span>;
}
function TeamBadge({ team }: { team: string }) {
  const cls: Record<string, string> = { Mystic: 'team-mystic', Valor: 'team-valor', Instinct: 'team-instinct' };
  return <span className={`badge ${cls[team] ?? 'team-mystic'}`}>{team}</span>;
}

// ─── TOAST ────────────────────────────────────────────────────────────────────
function Toast({ msg, onDone }: { msg: string; onDone: () => void }) {
  useEffect(() => { const t = setTimeout(onDone, 2500); return () => clearTimeout(t); }, [onDone]);
  return <div className="toast"><span style={{ color: 'var(--green)' }}>✓</span> {msg}</div>;
}

// ─── AUTH PAGE ────────────────────────────────────────────────────────────────
function AuthPage({ onAuth }: { onAuth: (u: UserProfile) => void }) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [step, setStep] = useState<'auth' | 'profile'>('auth');
  const [form, setForm] = useState({ username: '', password: '', trainerCode: '', level: 40, team: 'Mystic' as UserProfile['team'], region: 'North America', bio: '' });
  const [err, setErr] = useState('');

  function handleAuth() {
    if (!form.username.trim() || !form.password.trim()) { setErr('Please fill in all fields'); return; }
    if (form.password.length < 6) { setErr('Password must be at least 6 characters'); return; }
    setErr('');
    if (mode === 'signup') { setStep('profile'); return; }
    // Demo login — just create a profile
    finalize();
  }

  function finalize() {
    if (!form.trainerCode.trim() && mode === 'signup') { setErr('Trainer code is required'); return; }
    const profile: UserProfile = {
      id: Date.now().toString(),
      username: form.username || 'Trainer',
      trainerCode: form.trainerCode || '0000 0000 0000',
      level: form.level,
      team: form.team,
      region: form.region,
      bio: form.bio,
      joinedAt: new Date(),
      raidsHosted: 0,
      tradesCompleted: 0,
    };
    onAuth(profile);
  }

  const f = (k: string, v: string | number) => setForm(p => ({ ...p, [k]: v }));

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, position: 'relative', zIndex: 1 }}>
      {/* Background grid */}
      <div style={{ position: 'fixed', inset: 0, backgroundImage: 'linear-gradient(rgba(0,212,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.03) 1px,transparent 1px)', backgroundSize: '60px 60px', pointerEvents: 'none' }} />

      <div style={{ width: '100%', maxWidth: 460 }}>
        {/* Logo */}
        <div className="fade-up" style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: 'linear-gradient(135deg,#0099ff,#00d4ff)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, boxShadow: '0 0 30px rgba(0,212,255,0.4)' }}>⚡</div>
            <div style={{ textAlign: 'left' }}>
              <div className="display" style={{ fontSize: 28, letterSpacing: '-0.5px', color: 'var(--text)' }}>RaidNexus</div>
              <div style={{ fontSize: 12, color: 'var(--text3)', letterSpacing: 1.5, textTransform: 'uppercase', marginTop: -2 }}>Community Hub</div>
            </div>
          </div>
          <p style={{ color: 'var(--text2)', fontSize: 15 }}>Connect with trainers worldwide</p>
        </div>

        <div className="glass-card fade-up-1" style={{ padding: 32 }}>
          {step === 'auth' ? (
            <>
              {/* Mode toggle */}
              <div style={{ display: 'flex', background: 'var(--bg3)', borderRadius: 10, padding: 4, marginBottom: 28 }}>
                {(['login', 'signup'] as const).map(m => (
                  <button key={m} onClick={() => { setMode(m); setErr(''); }} style={{ flex: 1, padding: '9px 0', borderRadius: 7, border: 'none', cursor: 'pointer', fontFamily: 'DM Sans,sans-serif', fontWeight: 600, fontSize: 14, transition: 'all 0.15s', background: mode === m ? 'var(--bg4)' : 'transparent', color: mode === m ? 'var(--text)' : 'var(--text2)', boxShadow: mode === m ? '0 2px 6px rgba(0,0,0,0.3)' : 'none' }}>
                    {m === 'login' ? 'Sign In' : 'Create Account'}
                  </button>
                ))}
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div>
                  <label className="label">Username</label>
                  <input className="field" placeholder="TrainerName" value={form.username} onChange={e => f('username', e.target.value)} />
                </div>
                <div>
                  <label className="label">Password</label>
                  <input className="field" type="password" placeholder="••••••••" value={form.password} onChange={e => f('password', e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAuth()} />
                </div>
                {err && <div style={{ background: 'rgba(255,69,96,0.1)', border: '1px solid rgba(255,69,96,0.3)', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: 'var(--red)' }}>{err}</div>}
                <button className="btn btn-neon btn-lg" style={{ width: '100%', marginTop: 4 }} onClick={handleAuth}>
                  {mode === 'login' ? 'Sign In →' : 'Continue →'}
                </button>
              </div>

              <div className="divider" />
              <div style={{ textAlign: 'center', fontSize: 13, color: 'var(--text3)' }}>
                This is a community tool for coordinating gameplay.
              </div>
            </>
          ) : (
            <>
              <div style={{ marginBottom: 24 }}>
                <div className="display" style={{ fontSize: 22, marginBottom: 4 }}>Set up your profile</div>
                <div style={{ fontSize: 14, color: 'var(--text2)' }}>Your trainer info — you can change this later</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div>
                  <label className="label">Trainer Code <span style={{ color: 'var(--red)' }}>*</span></label>
                  <input className="field mono" placeholder="0000 0000 0000" value={form.trainerCode} onChange={e => f('trainerCode', e.target.value)} />
                  <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 6 }}>Found in your Pokémon GO profile</div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div>
                    <label className="label">Team</label>
                    <select className="field" value={form.team} onChange={e => f('team', e.target.value)}>
                      <option>Mystic</option><option>Valor</option><option>Instinct</option>
                    </select>
                  </div>
                  <div>
                    <label className="label">Level</label>
                    <input className="field" type="number" min={1} max={50} value={form.level} onChange={e => f('level', parseInt(e.target.value) || 1)} />
                  </div>
                </div>
                <div>
                  <label className="label">Region</label>
                  <select className="field" value={form.region} onChange={e => f('region', e.target.value)}>
                    {REGIONS.map(r => <option key={r}>{r}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label">Bio (optional)</label>
                  <input className="field" placeholder="Casual raider, always ready for T5s..." value={form.bio} onChange={e => f('bio', e.target.value)} />
                </div>
                {err && <div style={{ background: 'rgba(255,69,96,0.1)', border: '1px solid rgba(255,69,96,0.3)', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: 'var(--red)' }}>{err}</div>}
                <button className="btn btn-neon btn-lg" style={{ width: '100%', marginTop: 4 }} onClick={finalize}>
                  Launch RaidNexus 🚀
                </button>
                <button className="btn btn-ghost" style={{ width: '100%' }} onClick={() => setStep('auth')}>← Back</button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── PROFILE MODAL ────────────────────────────────────────────────────────────
function ProfileModal({ user, onClose, onSave }: { user: UserProfile; onClose: () => void; onSave: (u: UserProfile) => void }) {
  const [form, setForm] = useState({ ...user });
  const f = (k: string, v: string | number) => setForm(p => ({ ...p, [k]: v }));

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <div className="display" style={{ fontSize: 22 }}>My Profile</div>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24, padding: '16px', background: 'var(--bg3)', borderRadius: 12 }}>
          <Avatar name={form.username} size={52} />
          <div>
            <div className="display" style={{ fontSize: 20 }}>{form.username}</div>
            <div style={{ fontSize: 13, color: 'var(--text2)', marginTop: 2 }}>
              Raids hosted: <strong style={{ color: 'var(--neon)' }}>{form.raidsHosted}</strong> · Trades: <strong style={{ color: 'var(--neon)' }}>{form.tradesCompleted}</strong>
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div>
            <label className="label">Trainer Code</label>
            <input className="field mono" value={form.trainerCode} onChange={e => f('trainerCode', e.target.value)} placeholder="0000 0000 0000" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label className="label">Team</label>
              <select className="field" value={form.team} onChange={e => f('team', e.target.value)}>
                <option>Mystic</option><option>Valor</option><option>Instinct</option>
              </select>
            </div>
            <div>
              <label className="label">Level</label>
              <input className="field" type="number" min={1} max={50} value={form.level} onChange={e => f('level', parseInt(e.target.value) || 1)} />
            </div>
          </div>
          <div>
            <label className="label">Region</label>
            <select className="field" value={form.region} onChange={e => f('region', e.target.value)}>
              {REGIONS.map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Bio</label>
            <input className="field" value={form.bio} onChange={e => f('bio', e.target.value)} placeholder="Tell other trainers about yourself..." />
          </div>
          <button className="btn btn-neon" style={{ width: '100%', justifyContent: 'center', marginTop: 6 }} onClick={() => { onSave(form); onClose(); }}>
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── RAID CARD ────────────────────────────────────────────────────────────────
function RaidCard({ raid, onJoin }: { raid: Raid; onJoin: (code: string) => void }) {
  const [copied, setCopied] = useState(false);
  const { text, urgent } = timeLeft(new Date(raid.expiresAt));
  const pct = (raid.filled / raid.slots) * 100;
  const almostFull = pct >= 70;
  const full = raid.filled >= raid.slots;

  const barColor = full ? 'var(--red)' : almostFull ? 'var(--gold)' : 'var(--neon)';

  return (
    <div className="glass-card fade-up" style={{ padding: 22 }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
            <span className="display" style={{ fontSize: 20, color: 'var(--text)' }}>{raid.shiny ? '✨ ' : ''}{raid.pokemon}</span>
            <span className={`badge ${raid.mode === 'remote' ? 'tag-remote' : 'tag-local'}`}>{raid.mode === 'remote' ? '🌐 Remote' : '📍 Local'}</span>
            {full && <span className="badge" style={{ background: 'rgba(255,69,96,0.15)', color: 'var(--red)', border: '1px solid rgba(255,69,96,0.3)' }}>FULL</span>}
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            <TierBadge tier={raid.tier} />
            <TypeBadge type={raid.type} />
          </div>
        </div>
        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: urgent ? 'var(--red)' : 'var(--text2)' }}>
            {urgent && '⚡ '}{text}
          </div>
          <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 3 }}>📍 {raid.region}</div>
        </div>
      </div>

      {/* Note */}
      {raid.note && (
        <div style={{ background: 'rgba(240,180,41,0.06)', border: '1px solid rgba(240,180,41,0.15)', borderRadius: 8, padding: '8px 12px', marginBottom: 14, fontSize: 13, color: 'var(--text2)', borderLeft: '3px solid var(--gold)' }}>
          {raid.note}
        </div>
      )}

      {/* Slots */}
      <div style={{ marginBottom: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          <span style={{ fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Slots filled</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: almostFull ? 'var(--gold)' : 'var(--text2)' }}>{raid.filled} / {raid.slots}</span>
        </div>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${pct}%`, background: barColor }} />
        </div>
      </div>

      {/* Footer */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: 14, borderTop: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Avatar name={raid.hostName} size={30} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{raid.hostName}</div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--text3)' }}>{raid.hostCode}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 7 }}>
          <button className="btn btn-ghost btn-sm" onClick={() => copy(raid.hostCode, () => { setCopied(true); setTimeout(() => setCopied(false), 2000); })}>
            {copied ? '✓' : '📋'} {copied ? 'Copied' : 'Code'}
          </button>
          <button className="btn btn-neon btn-sm" disabled={full} style={{ opacity: full ? 0.5 : 1 }} onClick={() => onJoin(raid.hostCode)}>
            {full ? 'Full' : 'Join'}
          </button>
        </div>
      </div>
      <div style={{ marginTop: 8, fontSize: 11, color: 'var(--text3)' }}>Posted {timeAgo(new Date(raid.postedAt))}</div>
    </div>
  );
}

// ─── FRIEND CARD ──────────────────────────────────────────────────────────────
function FriendCard({ friend, onAdd }: { friend: FriendListing; onAdd: (code: string) => void }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="glass-card fade-up" style={{ padding: 22 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
        <div style={{ position: 'relative' }}>
          <Avatar name={friend.username} size={44} />
          {friend.online && <span style={{ position: 'absolute', bottom: -2, right: -2, width: 10, height: 10, background: 'var(--green)', borderRadius: '50%', border: '2px solid var(--bg2)' }} />}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5 }}>
            <span className="display" style={{ fontSize: 17 }}>{friend.username}</span>
            {friend.online && <span style={{ fontSize: 11, color: 'var(--green)', fontWeight: 600 }}>● ONLINE</span>}
          </div>
          <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
            <TeamBadge team={friend.team} />
            <span className="badge" style={{ background: 'var(--bg3)', color: 'var(--text3)', border: '1px solid var(--border)' }}>Lv {friend.level}</span>
            <span className="badge" style={{ background: 'var(--bg3)', color: 'var(--text3)', border: '1px solid var(--border)' }}>📍 {friend.region}</span>
          </div>
        </div>
      </div>
      <div className="mono" style={{ fontSize: 13, color: 'var(--neon)', background: 'rgba(0,212,255,0.05)', border: '1px solid rgba(0,212,255,0.15)', padding: '8px 12px', borderRadius: 8, marginBottom: 12, letterSpacing: 1 }}>
        {friend.trainerCode}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, color: 'var(--text3)' }}>Looking for:</span>
          {friend.looking.map(l => <span key={l} className="badge" style={{ background: 'var(--bg4)', color: 'var(--text2)', border: '1px solid var(--border)', textTransform: 'none', letterSpacing: 0 }}>{l}</span>)}
        </div>
        <div style={{ display: 'flex', gap: 7 }}>
          <button className="btn btn-ghost btn-sm" onClick={() => copy(friend.trainerCode, () => { setCopied(true); setTimeout(() => setCopied(false), 2000); })}>
            {copied ? '✓' : '📋'}
          </button>
          <button className="btn btn-outline btn-sm" onClick={() => onAdd(friend.trainerCode)}>Add Friend</button>
        </div>
      </div>
      <div style={{ marginTop: 10, fontSize: 11, color: 'var(--text3)' }}>Listed {timeAgo(new Date(friend.postedAt))}</div>
    </div>
  );
}

// ─── TRADE CARD ───────────────────────────────────────────────────────────────
function TradeCard({ trade, onContact }: { trade: Trade; onContact: (code: string) => void }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="glass-card fade-up" style={{ padding: 22 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 12, alignItems: 'center', marginBottom: 16 }}>
        <div style={{ background: 'var(--bg3)', borderRadius: 10, padding: '12px 14px', textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Offering</div>
          <div className="display" style={{ fontSize: 16, marginBottom: 6 }}>{trade.offeringShiny ? '✨ ' : ''}{trade.offering}</div>
          <TypeBadge type={trade.offeringType} />
        </div>
        <div style={{ fontSize: 20, color: 'var(--gold)', fontWeight: 700 }}>⇄</div>
        <div style={{ background: 'var(--bg3)', borderRadius: 10, padding: '12px 14px', textAlign: 'center' }}>
          <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5 }}>Wanting</div>
          <div className="display" style={{ fontSize: 16, marginBottom: 6 }}>{trade.wantingShiny ? '✨ ' : ''}{trade.wanting}</div>
          <TypeBadge type={trade.wantingType} />
        </div>
      </div>
      {trade.note && <div style={{ fontSize: 13, color: 'var(--text2)', background: 'var(--bg3)', borderRadius: 8, padding: '8px 12px', marginBottom: 12 }}>{trade.note}</div>}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', paddingTop: 14, borderTop: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Avatar name={trade.username} size={30} />
          <div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{trade.username}</div>
            <div style={{ fontSize: 11, color: 'var(--text3)' }}>📍 {trade.region} · {timeAgo(new Date(trade.postedAt))}</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 7 }}>
          <button className="btn btn-ghost btn-sm" onClick={() => copy(trade.trainerCode, () => { setCopied(true); setTimeout(() => setCopied(false), 2000); })}>
            {copied ? '✓' : '📋'}
          </button>
          <button className="btn btn-neon btn-sm" onClick={() => onContact(trade.trainerCode)}>Contact</button>
        </div>
      </div>
    </div>
  );
}

// ─── POST RAID MODAL ──────────────────────────────────────────────────────────
function PostRaidModal({ user, onClose, onPost }: { user: UserProfile; onClose: () => void; onPost: (r: Raid) => void }) {
  const [form, setForm] = useState({
    pokemon: 'Mewtwo', tier: '5' as RaidTier, type: 'psychic', mode: 'remote' as RaidMode,
    trainerCode: user.trainerCode, slots: 20, note: '', shiny: false,
  });
  const f = (k: string, v: string | number | boolean) => setForm(p => ({ ...p, [k]: v }));

  function submit() {
    const raid: Raid = {
      ...form, id: Date.now().toString(), filled: 0,
      hostCode: form.trainerCode, hostName: user.username, hostTeam: user.team,
      region: user.region, expiresAt: new Date(Date.now() + 45 * 60000), postedAt: new Date(),
    };
    onPost(raid);
    onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <div className="display" style={{ fontSize: 22 }}>Post a Raid</div>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><label className="label">Pokémon</label>
              <select className="field" value={form.pokemon} onChange={e => f('pokemon', e.target.value)}>
                {POKEMON_LIST.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div><label className="label">Tier</label>
              <select className="field" value={form.tier} onChange={e => f('tier', e.target.value as RaidTier)}>
                <option value="1">Tier 1</option><option value="3">Tier 3</option>
                <option value="5">Tier 5</option><option value="mega">Mega</option><option value="elite">Elite</option>
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><label className="label">Type</label>
              <select className="field" value={form.type} onChange={e => f('type', e.target.value)}>
                {TYPES.map(t => <option key={t} value={t}>{t[0].toUpperCase() + t.slice(1)}</option>)}
              </select>
            </div>
            <div><label className="label">Raid Mode</label>
              <select className="field" value={form.mode} onChange={e => f('mode', e.target.value as RaidMode)}>
                <option value="remote">🌐 Remote</option><option value="local">📍 Local</option>
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><label className="label">Your Trainer Code</label>
              <input className="field mono" value={form.trainerCode} onChange={e => f('trainerCode', e.target.value)} placeholder="0000 0000 0000" />
            </div>
            <div><label className="label">Max Slots</label>
              <select className="field" value={form.slots} onChange={e => f('slots', parseInt(e.target.value))}>
                {SLOT_OPTIONS.map(n => <option key={n} value={n}>{n} players</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="label">Note (optional)</label>
            <input className="field" placeholder="Counter tips, requirements..." value={form.note} onChange={e => f('note', e.target.value)} />
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', padding: '10px 14px', background: 'var(--bg3)', borderRadius: 10, border: '1px solid var(--border)' }}>
            <input type="checkbox" checked={form.shiny} onChange={e => f('shiny', e.target.checked)} style={{ width: 16, height: 16, accentColor: 'var(--gold)' }} />
            <span style={{ fontSize: 14, fontWeight: 500 }}>✨ Shiny available</span>
          </label>
          <button className="btn btn-neon" style={{ width: '100%', justifyContent: 'center', marginTop: 4 }} onClick={submit}>
            🚀 Post Raid
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── POST FRIEND MODAL ────────────────────────────────────────────────────────
function PostFriendModal({ user, onClose, onPost }: { user: UserProfile; onClose: () => void; onPost: (f: FriendListing) => void }) {
  const [looking, setLooking] = useState<string[]>(['raids']);
  const toggle = (item: string) => setLooking(p => p.includes(item) ? p.filter(x => x !== item) : [...p, item]);

  function submit() {
    const listing: FriendListing = {
      id: Date.now().toString(), username: user.username, trainerCode: user.trainerCode,
      level: user.level, region: user.region, team: user.team, looking,
      postedAt: new Date(), online: true,
    };
    onPost(listing);
    onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <div className="display" style={{ fontSize: 22 }}>Add Friend Listing</div>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <div style={{ background: 'var(--bg3)', borderRadius: 12, padding: '16px', marginBottom: 20 }}>
          <div style={{ fontSize: 13, color: 'var(--text2)', marginBottom: 8 }}>Posting as:</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Avatar name={user.username} size={36} />
            <div>
              <div style={{ fontWeight: 600 }}>{user.username}</div>
              <div className="mono" style={{ fontSize: 12, color: 'var(--text3)' }}>{user.trainerCode}</div>
            </div>
          </div>
        </div>
        <div style={{ marginBottom: 20 }}>
          <label className="label">Looking for</label>
          <div style={{ display: 'flex', gap: 8 }}>
            {['raids', 'trades', 'gifts'].map(item => (
              <button key={item} onClick={() => toggle(item)} style={{ flex: 1, padding: '10px', borderRadius: 9, border: `1px solid ${looking.includes(item) ? 'var(--neon)' : 'var(--border)'}`, background: looking.includes(item) ? 'rgba(0,212,255,0.1)' : 'var(--bg3)', color: looking.includes(item) ? 'var(--neon)' : 'var(--text2)', fontFamily: 'DM Sans,sans-serif', fontWeight: 600, fontSize: 14, cursor: 'pointer', transition: 'all 0.15s' }}>
                {item}
              </button>
            ))}
          </div>
        </div>
        <button className="btn btn-neon" style={{ width: '100%', justifyContent: 'center' }} onClick={submit}>
          👥 Post Listing
        </button>
      </div>
    </div>
  );
}

// ─── POST TRADE MODAL ─────────────────────────────────────────────────────────
function PostTradeModal({ user, onClose, onPost }: { user: UserProfile; onClose: () => void; onPost: (t: Trade) => void }) {
  const [form, setForm] = useState({ offering: 'Charizard', offeringType: 'fire', offeringShiny: false, wanting: 'Blastoise', wantingType: 'water', wantingShiny: false, note: '' });
  const f = (k: string, v: string | boolean) => setForm(p => ({ ...p, [k]: v }));

  function submit() {
    const trade: Trade = { ...form, id: Date.now().toString(), username: user.username, trainerCode: user.trainerCode, region: user.region, postedAt: new Date() };
    onPost(trade);
    onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <div className="display" style={{ fontSize: 22 }}>Post a Trade</div>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label className="label">Offering</label>
              <select className="field" value={form.offering} onChange={e => f('offering', e.target.value)}>
                {POKEMON_LIST.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Its Type</label>
              <select className="field" value={form.offeringType} onChange={e => f('offeringType', e.target.value)}>
                {TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', padding: '9px 14px', background: 'var(--bg3)', borderRadius: 9, border: '1px solid var(--border)' }}>
            <input type="checkbox" checked={form.offeringShiny} onChange={e => f('offeringShiny', e.target.checked)} style={{ accentColor: 'var(--gold)' }} />
            <span style={{ fontSize: 13, fontWeight: 500 }}>✨ This is shiny</span>
          </label>
          <div className="divider" style={{ margin: '4px 0' }} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label className="label">Wanting</label>
              <select className="field" value={form.wanting} onChange={e => f('wanting', e.target.value)}>
                {POKEMON_LIST.map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Its Type</label>
              <select className="field" value={form.wantingType} onChange={e => f('wantingType', e.target.value)}>
                {TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', padding: '9px 14px', background: 'var(--bg3)', borderRadius: 9, border: '1px solid var(--border)' }}>
            <input type="checkbox" checked={form.wantingShiny} onChange={e => f('wantingShiny', e.target.checked)} style={{ accentColor: 'var(--gold)' }} />
            <span style={{ fontSize: 13, fontWeight: 500 }}>✨ I want shiny only</span>
          </label>
          <div>
            <label className="label">Note (optional)</label>
            <input className="field" placeholder="Any preferences or requirements..." value={form.note} onChange={e => f('note', e.target.value)} />
          </div>
          <button className="btn btn-neon" style={{ width: '100%', justifyContent: 'center' }} onClick={submit}>⇄ Post Trade</button>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
type Tab = 'raids' | 'friends' | 'trades';
type Modal = null | 'raid' | 'friend' | 'trade' | 'profile';

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [tab, setTab] = useState<Tab>('raids');
  const [raids, setRaids] = useState<Raid[]>(SAMPLE_RAIDS);
  const [friends, setFriends] = useState<FriendListing[]>(SAMPLE_FRIENDS);
  const [trades, setTrades] = useState<Trade[]>(SAMPLE_TRADES);
  const [modal, setModal] = useState<Modal>(null);
  const [search, setSearch] = useState('');
  const [filterRegion, setFilterRegion] = useState('All');
  const [filterType, setFilterType] = useState('All');
  const [filterMode, setFilterMode] = useState('All');
  const [toast, setToast] = useState('');
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setProfileOpen(false);
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  if (!user) return <AuthPage onAuth={u => { setUser(u); setToast(`Welcome to RaidNexus, ${u.username}! 🎉`); }} />;

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 2500); };

  const liveRaids = raids.filter(r => new Date(r.expiresAt).getTime() > Date.now());

  const filteredRaids = liveRaids.filter(r => {
    const s = search.toLowerCase();
    return (r.pokemon.toLowerCase().includes(s) || r.hostName.toLowerCase().includes(s)) &&
      (filterRegion === 'All' || r.region === filterRegion) &&
      (filterType === 'All' || r.type === filterType) &&
      (filterMode === 'All' || r.mode === filterMode);
  });

  const filteredFriends = friends.filter(f => {
    const s = search.toLowerCase();
    return f.username.toLowerCase().includes(s) && (filterRegion === 'All' || f.region === filterRegion);
  });

  const filteredTrades = trades.filter(t => {
    const s = search.toLowerCase();
    return (t.offering.toLowerCase().includes(s) || t.wanting.toLowerCase().includes(s) || t.username.toLowerCase().includes(s)) &&
      (filterRegion === 'All' || t.region === filterRegion) &&
      (filterType === 'All' || t.offeringType === filterType || t.wantingType === filterType);
  });

  const postLabel = tab === 'raids' ? 'Post Raid' : tab === 'friends' ? 'Add Listing' : 'Post Trade';

  return (
    <div style={{ minHeight: '100vh', position: 'relative', zIndex: 1 }}>
      {/* Background grid */}
      <div style={{ position: 'fixed', inset: 0, backgroundImage: 'linear-gradient(rgba(0,212,255,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.025) 1px,transparent 1px)', backgroundSize: '60px 60px', pointerEvents: 'none', zIndex: 0 }} />

      {/* ── NAV ── */}
      <header style={{ background: 'rgba(6,8,16,0.85)', backdropFilter: 'blur(20px)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 50, padding: '0 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', height: 64, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: 'linear-gradient(135deg,#0099ff,#00d4ff)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17, boxShadow: '0 0 16px rgba(0,212,255,0.4)' }}>⚡</div>
            <div className="display" style={{ fontSize: 22, letterSpacing: '-0.3px' }}>RaidNexus</div>
          </div>

          {/* Right side */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '6px 14px', background: 'rgba(0,230,118,0.08)', border: '1px solid rgba(0,230,118,0.2)', borderRadius: 20 }}>
              <span className="live-dot" />
              <span className="mono" style={{ fontSize: 12, color: 'var(--green)', fontWeight: 500 }}>{liveRaids.length} live</span>
            </div>

            <button className="btn btn-neon btn-sm" onClick={() => setModal(tab === 'raids' ? 'raid' : tab === 'friends' ? 'friend' : 'trade')}>
              + {postLabel}
            </button>

            {/* Profile dropdown */}
            <div ref={profileRef} style={{ position: 'relative' }}>
              <button onClick={() => setProfileOpen(p => !p)} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 12px 6px 6px', background: 'var(--glass2)', border: '1px solid var(--border2)', borderRadius: 10, cursor: 'pointer', transition: 'all 0.15s' }}>
                <Avatar name={user.username} size={28} />
                <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>{user.username}</span>
                <span style={{ fontSize: 10, color: 'var(--text3)' }}>▾</span>
              </button>
              {profileOpen && (
                <div className="profile-menu">
                  <div style={{ padding: '12px 14px 10px', borderBottom: '1px solid var(--border)', marginBottom: 6 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{user.username}</div>
                    <div className="mono" style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>{user.trainerCode}</div>
                    <div style={{ marginTop: 6, display: 'flex', gap: 5 }}>
                      <TeamBadge team={user.team} />
                      <span className="badge" style={{ background: 'var(--bg3)', color: 'var(--text3)', border: '1px solid var(--border)' }}>Lv {user.level}</span>
                    </div>
                  </div>
                  <button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'flex-start', borderRadius: 8, marginBottom: 2 }} onClick={() => { setModal('profile'); setProfileOpen(false); }}>⚙️ Edit Profile</button>
                  <button className="btn btn-danger" style={{ width: '100%', justifyContent: 'flex-start', borderRadius: 8 }} onClick={() => { setUser(null); setProfileOpen(false); }}>← Sign Out</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 24px', position: 'relative', zIndex: 1 }}>
        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 32 }}>
          {[
            { label: 'Live Raids', value: liveRaids.length, sub: 'active now', color: 'var(--red)' },
            { label: 'Trainers', value: friends.length + 24, sub: 'online today', color: 'var(--neon)' },
            { label: 'Open Trades', value: trades.length, sub: 'looking to swap', color: 'var(--gold)' },
            { label: 'Your Raids', value: user.raidsHosted, sub: 'hosted', color: 'var(--purple)' },
          ].map((s, i) => (
            <div key={s.label} className={`glass-card fade-up-${i + 1}`} style={{ padding: '20px 22px' }}>
              <div style={{ fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: 0.8, fontWeight: 600, marginBottom: 8 }}>{s.label}</div>
              <div style={{ fontFamily: 'Rajdhani,sans-serif', fontSize: 34, fontWeight: 700, color: s.color, lineHeight: 1, marginBottom: 4 }}>{s.value}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)' }}>{s.sub}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
          <div className="tab-bar">
            {([['raids','⚔️ Raids', liveRaids.length], ['friends','👥 Friends', friends.length], ['trades','⇄ Trades', trades.length]] as const).map(([key, label, count]) => (
              <button key={key} className={`tab-btn ${tab === key ? 'active' : ''}`} onClick={() => { setTab(key); setSearch(''); setFilterType('All'); setFilterMode('All'); }}>
                {label} <span className="tab-count">{count}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 24, flexWrap: 'wrap' }}>
          <div className="search-wrap" style={{ flex: '1 1 220px', maxWidth: 300 }}>
            <span className="search-icon">🔍</span>
            <input className="field" placeholder={`Search ${tab}...`} value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="field" style={{ maxWidth: 160, flex: '0 0 auto' }} value={filterRegion} onChange={e => setFilterRegion(e.target.value)}>
            <option value="All">All Regions</option>
            {REGIONS.map(r => <option key={r}>{r}</option>)}
          </select>
          {tab !== 'friends' && (
            <select className="field" style={{ maxWidth: 150, flex: '0 0 auto' }} value={filterType} onChange={e => setFilterType(e.target.value)}>
              <option value="All">All Types</option>
              {TYPES.map(t => <option key={t} value={t}>{t[0].toUpperCase() + t.slice(1)}</option>)}
            </select>
          )}
          {tab === 'raids' && (
            <select className="field" style={{ maxWidth: 140, flex: '0 0 auto' }} value={filterMode} onChange={e => setFilterMode(e.target.value)}>
              <option value="All">All Modes</option>
              <option value="remote">🌐 Remote</option>
              <option value="local">📍 Local</option>
            </select>
          )}
          {tab === 'raids' && (
            <button className="btn btn-ghost btn-sm" onClick={() => setRaids(r => [...r].sort((a, b) => new Date(a.expiresAt).getTime() - new Date(b.expiresAt).getTime()))}>
              ⏱ Sort by Expiry
            </button>
          )}
        </div>

        {/* Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 16 }}>
          {tab === 'raids' && (filteredRaids.length > 0
            ? filteredRaids.map(r => <RaidCard key={r.id} raid={r} onJoin={code => { copy(code, () => showToast('Trainer code copied — add them in Pokémon GO!')); }} />)
            : <div className="empty-state" style={{ gridColumn: '1/-1' }}><div className="empty-icon">⚔️</div><div style={{ fontSize: 17, fontWeight: 600, marginBottom: 8 }}>No raids found</div><div style={{ fontSize: 14 }}>Post the first one!</div></div>
          )}
          {tab === 'friends' && (filteredFriends.length > 0
            ? filteredFriends.map(f => <FriendCard key={f.id} friend={f} onAdd={code => { copy(code, () => showToast('Code copied — add them in Pokémon GO!')); }} />)
            : <div className="empty-state" style={{ gridColumn: '1/-1' }}><div className="empty-icon">👥</div><div style={{ fontSize: 17, fontWeight: 600 }}>No trainers found</div></div>
          )}
          {tab === 'trades' && (filteredTrades.length > 0
            ? filteredTrades.map(t => <TradeCard key={t.id} trade={t} onContact={code => { copy(code, () => showToast('Code copied — contact them in Pokémon GO!')); }} />)
            : <div className="empty-state" style={{ gridColumn: '1/-1' }}><div className="empty-icon">⇄</div><div style={{ fontSize: 17, fontWeight: 600 }}>No trades found</div></div>
          )}
        </div>
      </main>

      {/* Modals */}
      {modal === 'raid' && <PostRaidModal user={user} onClose={() => setModal(null)} onPost={r => { setRaids(p => [r, ...p]); setUser(u => u ? { ...u, raidsHosted: u.raidsHosted + 1 } : u); showToast('Raid posted! 🚀'); }} />}
      {modal === 'friend' && <PostFriendModal user={user} onClose={() => setModal(null)} onPost={f => { setFriends(p => [f, ...p]); showToast('Friend listing added! 👥'); }} />}
      {modal === 'trade' && <PostTradeModal user={user} onClose={() => setModal(null)} onPost={t => { setTrades(p => [t, ...p]); showToast('Trade posted! ⇄'); }} />}
      {modal === 'profile' && <ProfileModal user={user} onClose={() => setModal(null)} onSave={u => { setUser(u); showToast('Profile updated!'); }} />}

      {/* Toast */}
      {toast && <Toast msg={toast} onDone={() => setToast('')} />}
    </div>
  );
}
