export type RaidTier = '1' | '3' | '5' | 'mega' | 'elite';
export type RaidMode = 'remote' | 'local';

export interface UserProfile {
  id: string;
  username: string;
  trainerCode: string;
  level: number;
  team: 'Mystic' | 'Valor' | 'Instinct';
  region: string;
  bio: string;
  joinedAt: Date;
  raidsHosted: number;
  tradesCompleted: number;
}

export interface Raid {
  id: string;
  pokemon: string;
  tier: RaidTier;
  type: string;
  mode: RaidMode;
  hostCode: string;
  hostName: string;
  hostTeam: string;
  region: string;
  slots: number;
  filled: number;
  expiresAt: Date;
  postedAt: Date;
  note?: string;
  shiny?: boolean;
}

export interface FriendListing {
  id: string;
  username: string;
  trainerCode: string;
  level: number;
  region: string;
  team: 'Mystic' | 'Valor' | 'Instinct';
  looking: string[];
  postedAt: Date;
  online: boolean;
}

export interface Trade {
  id: string;
  username: string;
  trainerCode: string;
  offering: string;
  offeringType: string;
  offeringShiny: boolean;
  wanting: string;
  wantingType: string;
  wantingShiny: boolean;
  region: string;
  note?: string;
  postedAt: Date;
}

const now = new Date();
const min = (n: number) => new Date(now.getTime() + n * 60000);
const ago = (n: number) => new Date(now.getTime() - n * 60000);

export const SAMPLE_RAIDS: Raid[] = [
  { id:'r1', pokemon:'Mewtwo', tier:'5', type:'psychic', mode:'remote', hostCode:'1234 5678 9012', hostName:'ShadowTrainer', hostTeam:'Valor', region:'North America', slots:20, filled:7, expiresAt:min(28), postedAt:ago(2), note:'Bring Shadow Ball counters pls!', shiny:false },
  { id:'r2', pokemon:'Charizard', tier:'mega', type:'fire', mode:'remote', hostCode:'9876 5432 1098', hostName:'AquaRider', hostTeam:'Mystic', region:'Europe', slots:20, filled:3, expiresAt:min(41), postedAt:ago(1), shiny:true },
  { id:'r3', pokemon:'Rayquaza', tier:'5', type:'dragon', mode:'remote', hostCode:'5555 1234 8888', hostName:'DragonMaster', hostTeam:'Instinct', region:'Asia', slots:10, filled:9, expiresAt:min(9), postedAt:ago(8), note:'Almost full — join NOW', shiny:false },
  { id:'r4', pokemon:'Blastoise', tier:'mega', type:'water', mode:'local', hostCode:'2222 3333 4444', hostName:'CityHunter', hostTeam:'Valor', region:'North America', slots:20, filled:5, expiresAt:min(35), postedAt:ago(5), shiny:false },
  { id:'r5', pokemon:'Lucario', tier:'3', type:'fighting', mode:'remote', hostCode:'7777 8888 9999', hostName:'IronFist', hostTeam:'Mystic', region:'Australia', slots:5, filled:0, expiresAt:min(44), postedAt:ago(0), note:'Need full lobby of 5', shiny:false },
  { id:'r6', pokemon:'Dialga', tier:'elite', type:'steel', mode:'remote', hostCode:'1111 2222 3333', hostName:'TimeLord', hostTeam:'Instinct', region:'South America', slots:20, filled:11, expiresAt:min(19), postedAt:ago(11), shiny:false },
  { id:'r7', pokemon:'Gengar', tier:'mega', type:'ghost', mode:'remote', hostCode:'4444 5555 6666', hostName:'NightCrawler', hostTeam:'Valor', region:'Europe', slots:20, filled:6, expiresAt:min(31), postedAt:ago(4), shiny:true },
  { id:'r8', pokemon:'Groudon', tier:'5', type:'ground', mode:'local', hostCode:'3333 4444 5555', hostName:'EarthShaker', hostTeam:'Valor', region:'North America', slots:20, filled:15, expiresAt:min(22), postedAt:ago(18), note:'Central Park Gym — bring fire types!', shiny:false },
  { id:'r9', pokemon:'Regigigas', tier:'elite', type:'normal', mode:'remote', hostCode:'6666 7777 8888', hostName:'Korvus', hostTeam:'Mystic', region:'Asia', slots:20, filled:2, expiresAt:min(50), postedAt:ago(0), shiny:false },
  { id:'r10', pokemon:'Kyogre', tier:'5', type:'water', mode:'remote', hostCode:'9999 0000 1111', hostName:'OceanWave', hostTeam:'Instinct', region:'Global', slots:20, filled:8, expiresAt:min(33), postedAt:ago(7), shiny:true },
];

export const SAMPLE_FRIENDS: FriendListing[] = [
  { id:'f1', username:'ShadowTrainer', trainerCode:'1234 5678 9012', level:47, region:'North America', team:'Valor', looking:['raids','gifts'], postedAt:ago(10), online:true },
  { id:'f2', username:'AquaRider', trainerCode:'9876 5432 1098', level:42, region:'Europe', team:'Mystic', looking:['trades','raids'], postedAt:ago(25), online:true },
  { id:'f3', username:'DragonMaster', trainerCode:'5555 1234 8888', level:50, region:'Asia', team:'Instinct', looking:['gifts'], postedAt:ago(5), online:false },
  { id:'f4', username:'CityHunter', trainerCode:'2222 3333 4444', level:45, region:'North America', team:'Valor', looking:['raids','trades','gifts'], postedAt:ago(40), online:true },
  { id:'f5', username:'IronFist', trainerCode:'7777 8888 9999', level:38, region:'Australia', team:'Mystic', looking:['raids'], postedAt:ago(15), online:false },
  { id:'f6', username:'TimeLord', trainerCode:'1111 2222 3333', level:50, region:'South America', team:'Instinct', looking:['trades'], postedAt:ago(60), online:true },
];

export const SAMPLE_TRADES: Trade[] = [
  { id:'t1', username:'ShadowTrainer', trainerCode:'1234 5678 9012', offering:'Shiny Charizard', offeringType:'fire', offeringShiny:true, wanting:'Shiny Blastoise', wantingType:'water', wantingShiny:true, region:'North America', postedAt:ago(30) },
  { id:'t2', username:'AquaRider', trainerCode:'9876 5432 1098', offering:'Mewtwo', offeringType:'psychic', offeringShiny:false, wanting:'Lugia', wantingType:'flying', wantingShiny:false, region:'Europe', note:'Level 40+ preferred', postedAt:ago(45) },
  { id:'t3', username:'DragonMaster', trainerCode:'5555 1234 8888', offering:'Rayquaza', offeringType:'dragon', offeringShiny:false, wanting:'Dialga', wantingType:'steel', wantingShiny:false, region:'Asia', postedAt:ago(20) },
  { id:'t4', username:'CityHunter', trainerCode:'2222 3333 4444', offering:'Shiny Gyarados', offeringType:'water', offeringShiny:true, wanting:'Shiny Magikarp', wantingType:'water', wantingShiny:true, region:'North America', postedAt:ago(90) },
  { id:'t5', username:'TimeLord', trainerCode:'1111 2222 3333', offering:'Garchomp', offeringType:'dragon', offeringShiny:false, wanting:'Togekiss', wantingType:'fairy', wantingShiny:false, region:'South America', note:'Any trade works', postedAt:ago(12) },
];

export const POKEMON_LIST = [
  'Mewtwo','Rayquaza','Groudon','Kyogre','Lugia','Ho-Oh','Articuno','Zapdos','Moltres',
  'Dialga','Palkia','Giratina','Darkrai','Regigigas','Regice','Registeel','Regirock',
  'Charizard','Blastoise','Venusaur','Gengar','Lucario','Garchomp','Dragonite','Tyranitar',
  'Machamp','Alakazam','Gyarados','Lapras','Snorlax','Togekiss','Espeon','Umbreon',
  'Sylveon','Glaceon','Leafeon','Vaporeon','Jolteon','Flareon','Arcanine','Nidoking',
];

export const REGIONS = ['North America','Europe','Asia','Australia','South America','Africa','Global'];
export const TYPES = ['fire','water','grass','electric','psychic','dragon','ice','fighting','normal','ghost','dark','steel','fairy','rock','ground','flying','bug','poison'];
export const SLOT_OPTIONS = [2,3,4,5,6,8,10,12,15,20];
